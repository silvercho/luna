package study.EndGame.constant;

public enum UserRole {
    USER, ADMIN;
}
