package study.EndGame.constant;

public enum CarSellStatus {
    SELL, SOLD_OUT
}
