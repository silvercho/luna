package study.EndGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
