import React from 'react';

export default function Project() {
  return (
    <div>
      <h1>This is Projects page</h1>
    </div>
  );
}
