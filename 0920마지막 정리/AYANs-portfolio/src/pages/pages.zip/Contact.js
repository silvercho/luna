import React from 'react';

export default function Contact() {
  return (
    <div>
      <h1>This is Contact Page</h1>
    </div>
  );
}
